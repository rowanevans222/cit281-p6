async function fetchItems() {
  const res = await fetch('/items');
  const items = await res.json();
  const list = document.getElementById('items-list');
  list.innerHTML = '';

  items.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = `
      <strong>${item.name}</strong>: ${item.description}<br/>
      <button onclick="deleteItem(${item.id})">Delete</button>
      <button onclick="editItem(${item.id}, '${item.name}', '${item.description}')">Edit</button>
    `;
    list.appendChild(li);
  });
}

async function addItem() {
  const name = document.getElementById('name').value.trim();
  const description = document.getElementById('description').value.trim();
  if (!name || !description) return alert("Please enter both fields.");

  const res = await fetch('/items', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description })
  });

  if (res.ok) {
    document.getElementById('name').value = '';
    document.getElementById('description').value = '';
    fetchItems();
  }
}

async function deleteItem(id) {
  await fetch(`/items/${id}`, { method: 'DELETE' });
  fetchItems();
}

async function editItem(id, currentName, currentDescription) {
  const name = prompt("Edit name:", currentName);
  const description = prompt("Edit description:", currentDescription);
  if (!name || !description) return;

  await fetch(`/items/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description })
  });

  fetchItems();
}

// Load items on page load
fetchItems();