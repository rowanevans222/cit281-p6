// Import required modules
const express = require('express');
const app = express();
const PORT = 3000;

// Middleware to parse JSON and serve static files from /public
app.use(express.json());
app.use(express.static('public'));

// In-memory array of objects (pseudo-database)
let items = [
  { id: 1, name: "Item 1", description: "This is item 1" },
  { id: 2, name: "Item 2", description: "This is item 2" }
];
let nextId = 3;

// =========================
//       ROUTES
// =========================

// GET: Return all items
app.get('/items', (req, res) => {
  res.json(items);
});

// POST: Add a new item
app.post('/items', (req, res) => {
  const { name, description } = req.body;

  if (!name || !description) {
    console.error("POST Error: Missing name or description");
    return res.status(400).json({ error: "Missing name or description" });
  }

  const newItem = { id: nextId++, name, description };
  items.push(newItem);
  res.status(201).json(newItem);
});

// PUT: Update an existing item
app.put('/items/:id', (req, res) => {
  const itemId = parseInt(req.params.id);
  const { name, description } = req.body;
  const item = items.find(i => i.id === itemId);

  if (!item) {
    console.error(`PUT Error: Item ${itemId} not found`);
    return res.status(404).json({ error: "Item not found" });
  }

  if (!name || !description) {
    console.error("PUT Error: Missing name or description");
    return res.status(400).json({ error: "Missing name or description" });
  }

  item.name = name;
  item.description = description;
  res.json(item);
});

// DELETE: Remove an item
app.delete('/items/:id', (req, res) => {
  const itemId = parseInt(req.params.id);
  const index = items.findIndex(i => i.id === itemId);

  if (index === -1) {
    console.error(`DELETE Error: Item ${itemId} not found`);
    return res.status(404).json({ error: "Item not found" });
  }

  const deletedItem = items.splice(index, 1)[0];
  res.json(deletedItem);
});

// 404 handler for undefined routes
app.use((req, res) => {
  console.error("404 Error: Invalid URL");
  res.status(404).json({ error: "Not found" });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
